# Keep WebView JS interface
-keepclassmembers class com.fanstatic.mc.MainActivity$WebAppInterface {
    public *;
}
